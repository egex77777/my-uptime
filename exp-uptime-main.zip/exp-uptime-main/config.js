module.exports = ({
    token: "Botunuzun Tokenini Girin",
    secret: "Botunuzun Secretini Girin",
    clientID: "Botunuzun ID'sini Girin",
    link: "https://sitedomaininizigirin.com",
    guild: "Sunucu ID'sini Girin",
    invite: "Davet Kodunu Girin",
    adminrole: "Admin Rol ID'sini Girin",
    premiumrole: "Premium Rol ID'sini Girin",
    logchannel: "Log Kanal ID'sini Girin",
    port: 80,
    maxlink: 3,
    premiummaxlink: 6
})